# Comms Rules (Project Instructions)

Exported 2026-10-12 from the CF7638 project instructions.

## Audience rules

| Audience | Rule |
|---|---|
| Walmart or McKesson leadership (email) | Name the problem, own it where appropriate, lead with the action already taken or proposed. Never deflect blame onto individual employees. |
| Internal Teams messages | Brief and action oriented. |
| Team communications | Peer to peer. No condescension toward techs or peers. |
| Disciplinary and accountability messages | Firm but fair. |
| Executive updates | 2 to 3 sentence briefs, data forward. |

## Format rules

- Bullets and structured layouts for operational content.
- Tables for reports, scorecards, and rubrics.
- Step by step for technical troubleshooting.
- Word docs destined for email: build all header and footer content in the document body, not Word's native header/footer zones. Content in those zones is lost when pasted into Outlook.

## Palette

| Name | Hex |
|---|---|
| McKesson Navy | #003C71 |
| McKesson Orange | #E87722 |
| Light Blue | #E8F1F8 |
