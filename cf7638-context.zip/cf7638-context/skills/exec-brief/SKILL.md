---
name: exec-brief
description: Drafts executive briefs, leadership updates, and customer facing communications for McKesson and Walmart leadership at Central Fill CF7638. Use this skill whenever Matt is writing to Patrick Alfonso, Aaron Wolfe, Mark Edwards, Mick Godsey, Alex Hennum, Paul Di Scioscia, or any Walmart or McKesson leadership audience. Trigger on requests to draft an email or update to leadership, summarize an event or month for executives, escalate an issue upward, ask for headcount or budget, report a miss, or prepare talking points for the War Room, the Monthly Facilities Call, or the weekly Walmart facility meeting. Use it even when the request just says "write Patrick" or "let Aaron know."
---

# Executive Brief

Leadership communication for Matt's audiences. The failure mode these
documents avoid is burying the ask or the bad news three paragraphs down.

## Read the audience first

**Patrick Alfonso**, Director of Pharmacy Operations. Matt's manager. Site
level decisions, PM compliance, staffing, disciplinary matters. Assumes site
context, does not need equipment explained.

**Aaron Wolfe**, Director of Facilities Programs. Peer director with
functional authority. Network wide facilities standards, cross site
comparison, program level work. Not the Workday line, so requests here are
framed as alignment rather than approval.

**Mark Edwards**, skip level. Only when Patrick has routed it up or the
matter is genuinely above site level.

**Alex Hennum**, VP and GM Central Fill. Executive. Outcome and risk only,
no mechanism.

**Paul Di Scioscia**, Walmart GM Health and Wellness. The customer. Service
impact, what was done, what prevents recurrence. Never internal staffing
detail, never named employees, never proprietary equipment names if the
document might travel.

## Default shape

Two to three sentences for a routine update. Matt's standing preference is
short. Length is earned by consequence, not by topic.

For anything longer, this order:

1. **The point.** What happened or what is being asked. First sentence.
2. **The number.** The one figure that sizes it. Pulled from a real source,
   not estimated.
3. **What has been done.** Action already taken, in the past tense.
4. **What is needed.** The ask, if there is one, stated plainly with a date.

Never open with background. Never close with a summary of what was just
said.

## Bad news

Name the problem in the first sentence. Own the part McKesson owns. Lead
with the action already taken or proposed.

Never deflect blame onto individual employees, in any direction, internal or
customer facing. If a personnel issue is the cause, the document says the
process gap; the DA process handles the person separately.

Do not sugarcoat. Transparent with leadership is the standing rule, and a
softened miss that surfaces later is worse than a direct one now.

## Asking for something

State the ask, the cost, the consequence of not doing it, and the date a
decision is needed. One paragraph.

For headcount, tie it to coverage. Sunday is the peak day and runs on the
thinnest supervisor coverage. Friday runs on one supervisor. Those are the
structural facts that make a staffing case.

## Data

Pull the number, do not estimate it. Nightly recap emails in Outlook for
production, Cetaris for PM compliance and work orders, System Manager for
production queries, Mason's dashboard for OEE and downtime.

Validate OEE target rates before citing an OEE figure. They have been set
wrong by the dev team more than once.

Before attributing a pattern to an asset or a drug, normalize against
throughput. Apparent top offenders in this data are usually volume effects.

## Rules

No em dashes.

No preamble, no "I wanted to reach out," no "I hope this finds you well."

Peer to peer register with McKesson leadership. Professional and direct with
Walmart. Never deferential, never padded.

Specific numbers, specific dates, specific asset IDs. Matt audits these.

For customer facing documents, keep proprietary equipment names out:
FlexBed, LVD, ScriptPick, Unilabeler, Sprint, Tompkins, t-Sort. Substitute
generic descriptions.

## Meeting prep

For the War Room (Tuesdays, Matt owns it), the Monthly Facilities Call
(Aaron hosts), or the Monday Walmart facility meeting, produce talking
points rather than prose. Three to five bullets, each one a claim plus the
number behind it, ordered by what Matt wants decided.
