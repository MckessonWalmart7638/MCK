---
name: ops-scorecard
description: Populates, verifies, and maintains the monthly site scorecard workbook for McKesson Central Fill CF7638 Frederick. Use this skill whenever Matt mentions the scorecard, the monthly scorecard, the Maryland scorecard, service level reporting, adjusted service level, scripts filled or received, reject reasons, per-store averages, or the monthly numbers going to Walmart and McKesson distribution lists. Also use when he is adding a month tab, checking scorecard formulas, comparing Frederick against Orlando, or troubleshooting a broken total. Use it even if he only says "run the numbers for last month."
---

# Ops Scorecard

The monthly site scorecard. It goes to both Walmart and McKesson distribution
lists in the first week of the following month, so the numbers are customer
facing and get audited.

## Two hazards that have already caused damage

**Never open and re-save the Orlando workbook with any tool.** Its Service
Level and Y-o-Y Volume tabs pull from a separate external file through 217
linked formulas. Those cells hold cached values only. Any tool that resolves
the link and fails deletes the entire service level history permanently. The
Frederick workbook has no external links and is safe to work on.

**Never copy a month tab forward without checking it first.** A broken
template propagated 72 `#REF!` errors into five future months at once. Before
duplicating any tab, scan it for `#REF!`. If it has any, fix the source first.

## Schema

29 columns, A through AC, matching Orlando.

| Col | Field | Type |
|---|---|---|
| A | Weekday | fixed |
| B | Date | input |
| C | Number of Stores Serviced | formula, points at the assumptions cell |
| D | Number of Scripts Received | formula, `=SUM(E,Q)` |
| E | Number of Scripts Filled | input |
| F | Projected Scripts | input |
| G | % To Filled to Projected | formula, `=E/F` |
| H | Future Orders Released | input |
| I | Average Hourly Production | formula, `=E/N` |
| J | Futures Waiting at end of production | input |
| K | Total Cancelations | input |
| L | Production Start Time | input, time format |
| M | Sorting Complete Time | input, time format |
| N | Production Hours | formula, `=(M-L)*24` |
| O | Non Production Hours | input |
| P | Non Production Hours % | formula, `=O/(N+O)` |
| Q | Number of Scripts Omitted | formula, `=SUM(R:Y)` |
| R | No Product Found | input |
| S | Quantity Unavailable | input |
| T | Out of Inventory | input |
| U | Pack size Not Found | input |
| V | Host canceled order | input |
| W | Order arrived too late to be processed | input |
| X | Store Blackout Window | input |
| Y | All Other rejects | input |
| Z | Service Level to Customer (RAW) | formula, `=E/D` |
| AA | Average Scripts Sent Per Store | formula, `=D/C` |
| AB | Average Scripts Filled Per Store | formula, `=E/C` |
| AC | Adjusted Service Level to Customer | formula, see below |

Yellow fill marks input cells. Everything else is a formula. Never write into
a formula cell.

## Adjusted service level

`AC = (E + U + V + W + X) / D`

Credits back only rejects outside McKesson control: Pack size Not Found, Host
canceled order, Order arrived too late, Store Blackout Window. Matches Orlando
exactly.

It deliberately does not credit No Product Found, Quantity Unavailable, Out of
Inventory, or All Other Rejects. Those are inventory and internal.

The pre-FY27 Frederick formula credited eight reject reasons, which pushed
adjusted service level artificially high. Any month-over-month comparison that
crosses that boundary is not like for like. Say so rather than letting the
drop read as a performance miss.

Open item: Molly Lopez owns service level definition consistency across
Walmart sites. Confirm with her before a disputed number goes to the customer.

## Row structure

Six week blocks, Sunday through Friday. No Saturday row, the site is dark.

| Block | Day rows | Total row |
|---|---|---|
| Week 1 | 2 to 7 | 8 |
| Week 2 | 9 to 14 | 15 |
| Week 3 | 16 to 21 | 22 |
| Week 4 | 23 to 28 | 29 |
| Week 5 | 30 to 35 | 36 |
| Week 6 | 37 to 42 | 43 |

MTD is row 44. Daily Average is row 45. Assumptions block starts at row 48.

Unused week blocks stay blank and contribute zero. Months spanning five
calendar weeks leave week 6 empty.

**Count columns** sum across the block. **Ratio columns** (G, I, P, Z, AA, AB,
AC) are recomputed from the aggregate inputs at every total row. Never sum or
average a percentage column to produce an aggregate. Orlando does this and it
is wrong.

## Assumptions

Store count lives in one cell at row 49. Every C cell and every per-store
average references it. Update it there and nowhere else. Frederick runs
roughly 650 stores. If a per-store average looks wrong, check this cell first,
since an Orlando copy carries 480.

Service level goal is greater than 99.00 percent.

## Monthly workflow

1. Confirm the target tab has no `#REF!` before touching it.
2. Pull the daily figures. Sources below.
3. Enter dates in column B and fill the yellow input cells only.
4. Verify: Q should equal the sum of R through Y, and D should equal E plus Q.
   If either fails, an input is in the wrong column.
5. Sanity check Z and AC against the prior month. A swing of more than a point
   without a known event means an input error, not a performance change.
6. Recalculate and confirm zero formula errors before distributing.

## Data sources

| Need | Source |
|---|---|
| Daily scripts, service level, volume | Nightly recap emails in Outlook |
| Production queries, Rx by state, hourly projection, FIFO | System Manager |
| Downtime context behind a bad day | Cetaris, Mason's OEE dashboard |
| Reject reason detail | System Manager |

Pull the numbers. Never estimate a figure that goes to the customer.

## The email version

The workbook is one deliverable. The email summary sent to both distribution
lists is a separate artifact with its own format. If Matt has not supplied
that format, ask rather than inventing one.

For the email body, lead with MTD scripts filled, raw and adjusted service
level against the 99 percent goal, and the month-over-month direction. Name
any event that explains a miss. Do not attach internal staffing detail.

## Rules

No em dashes.

Match the prior month's format exactly when updating. Same structure, same
formulas, values only.

Cite specific figures and date ranges. Matt audits these and a wrong number
in a customer facing document gets caught.

Before attributing a service level miss to an asset or a drug, normalize
against throughput. Apparent top offenders in this data are usually volume
effects.
