---
name: da-notice
description: Drafts disciplinary action notices, coaching documentation, and attendance or performance write-ups for McKesson Central Fill CF7638, and routes them correctly through HR. Use this skill whenever Matt mentions a DA, a write-up, a corrective action, an attendance occurrence, a no-call no-show, a policy violation, falsification, a coaching conversation he needs documented, or asks how to handle an employee issue. Also use when he is reviewing labor logs against security footage or working out whether an absence counts as an occurrence. Use it even if he only says "I need to write someone up."
---

# DA Notice

Disciplinary documentation and the routing that goes with it. These carry
legal and HR consequence, so the process rules matter as much as the wording.

## Process rules, non-negotiable

**Timing.** DAs must be submitted within 3 weeks of the incident. If the
incident is older than that, say so before drafting and flag that the window
may have closed.

**Sequence.** Submit documentation to HR, wait for Employee Relations
approval, then deliver to the employee. Never deliver first.

**Falsification** routes through Employee Relations in Workday, not Manager
Self Service. This is a different path from standard DAs and getting it
wrong stalls the case.

**Attendance.** Denied PTO followed by an absence is an unexcused occurrence
under the nonexempt attendance policy. No grace period.

**Labor log analysis.** When cross referencing labor logs against security
footage, exclude sanctioned break times from the violation analysis. Failing
to exclude them produces violations that do not survive review.

PTO and LOA handling follows McKesson and MetLife policy. When a case
touches leave, flag it for HR rather than resolving it in the document.

## Before drafting

Confirm these or mark them unknown:

- Date and time of the incident, specific
- Which policy or standard was violated, named
- Prior documented conversations or DAs, with dates
- Whether the employee has been spoken to informally
- Whether this is the first, second, or final step
- Shift and supervisor, since the supervisor usually delivers

If prior history is unclear, get it before drafting. Escalation level
depends on it and an incorrectly leveled DA gets returned.

## Structure

**Employee and role.** Name, position, shift, supervisor.

**Incident.** Date, time, what occurred. Factual and specific. What was
observed or recorded, not what was inferred. No characterization of intent.

**Policy.** The specific policy or standard, named. Attendance policy,
safety standard, LOTO requirement, whatever applies.

**Prior history.** Dated list of relevant prior documentation. If none,
state that this is the first documented occurrence.

**Expectation.** What the employee is required to do going forward, stated
concretely enough to be measurable.

**Consequence.** What follows if the expectation is not met. Accurate to the
actual policy step, not inflated.

**Acknowledgment.** Signature lines for employee and manager, with a line
noting that signature confirms receipt rather than agreement.

## Tone

Firm but fair. This is Matt's standing rule for anything disciplinary.

Factual, not accusatory. Describe the behavior and its effect, not the
person's character or presumed motive.

No condescension. These employees are colleagues who will be on shift again
Monday.

Never sarcastic, never softened to the point of ambiguity. If the document
does not make clear that something must change, it has failed.

## Safety cases

LOTO compliance is zero tolerance at this site and OSHA 1910.147 is strictly
enforced. Safety violations are documented at the appropriate severity, not
coached down. If a case involves LOTO, say so explicitly in the draft and
flag it for a safety review in parallel with the HR process.

## Rules

No em dashes.

Never include an employee name in anything that leaves internal channels.

If the request is really about whether to write someone up rather than how,
say what the policy supports and what the options are. Do not draft a
document Matt has not decided to issue.

Documentation lives in the proper HR channel. Do not suggest a side file or
an informal record as a substitute.
