---
name: rca-writeup
description: Produces root cause analysis documents for equipment downtime and fault events at McKesson Central Fill CF7638. Use this skill whenever Matt mentions an RCA, a downtime event, a significant fault, a machine going down, a recurring failure, a "what happened" writeup, or asks to document or investigate an equipment issue. Also use when preparing a post-event summary for Walmart leadership, when analyzing fault data or top-faulted assets, or when reviewing downtime trends ahead of the Thursday OEE call. Use it even if the word "RCA" is never said.
---

# RCA Writeup

Produces the RCA document Matt uses for significant downtime events. He
leads RCA for all significant events at the site, and these documents feed
the Master Troubleshooting Guide and the Academy knowledgebase, so they need
to hold up months later when someone hits the same fault.

## Before writing

Pull real data. Do not write an RCA from conversation alone.

| Need | Source |
|---|---|
| Work order history, prior occurrences, labor | Cetaris CMMS |
| Fault codes, event and application logs | Beckhoff / TwinCAT extraction |
| Open technical issues | ServiceNow INC, THD for Tompkins |
| Production impact, volume during window | Nightly recap emails in Outlook |
| Downtime and OEE context | Mason's weekly dashboard |

If a data source is unavailable, write MISSING DATA in that field rather
than estimating. An RCA with an honest gap is more useful than one with a
plausible guess.

## Two traps to check every time

**Volume masquerading as causation.** In high volume pharmacy data, apparent
top offender patterns usually reflect throughput, not equipment or drug
specific failure. Before naming an asset or an NDC as the problem, normalize
against volume. State explicitly that this check was run.

**OEE target rates.** The dev team has set them incorrectly more than once,
which distorts machine OEE. Validate the target rate before drawing any
conclusion from an OEE figure.

## Mechanical or controls

Get the ownership call right, because it determines who fixes it and who
gets escalated to.

Matt's team owns mechanical, hardware, wear parts, alignment, physical jams.
Controls and Software (Vanessa Rico, the group also called RXAS, CoverMyMeds,
CMM, Sanitas) owns software behavior, PLC logic, recipe and parameter
changes, vision configuration.

The line blurs on scanner no-reads and photo eye faults. They present as
software and usually resolve as alignment or contamination. Rule out the
mechanical cause before assigning to controls.

## Structure

**Event summary.** What went down, when, for how long, what production
impact. Two to four sentences. Specific times and specific asset IDs.

**Timeline.** Table. Time, event, who acted. Start at first symptom, not at
first alarm. Include the escalation points and when each was reached.

**Investigation.** What was checked and what it showed, including things
checked and ruled out. Ruled-out causes matter as much as the confirmed one,
because the next person hitting this fault will start where you started.

**Root cause.** One paragraph. Name the actual mechanism. "Gripper pad wear
beyond tolerance caused intermittent product release at the transfer point"
is a root cause. "Equipment malfunction" is not. If the investigation did
not reach a confirmed root cause, say so and state what would be needed to
confirm it.

**Contributing factors.** Where they exist. PM interval, parts availability,
staffing on shift, prior deferred work. Be honest about these, including
when the answer implicates the maintenance program.

**Corrective action.** Table. Action, owner, due date, status. Immediate fix
and durable fix separated. If the durable fix is a PM change, name the PM.
If it is a spare part par level, name the part.

**Recurrence check.** Prior occurrences from Cetaris with dates and work
order numbers. If this is the first occurrence, say so explicitly.

**Documentation.** Work order numbers, INC or THD tickets, any SOP or STP
that needs revision as a result.

## Rules

Cite specific numbers, date ranges, work order numbers, and asset IDs. Matt
audits these and sloppy citations or misattributed work orders get sent back.

Documentation lives in CMMS only. Never suggest a quick fix sheet or a
side document as the record.

No em dashes.

Never assign fault to a named individual in the document. Describe what
happened and what the process gap was. Personnel issues route through the DA
process separately.

## Customer facing version

When the RCA is going to Walmart, Paul Di Scioscia or his team, produce a
separate condensed version rather than sending the internal document.

Transparent, factual, solution forward. Name the problem, own it where
McKesson owns it, lead with the action already taken or proposed. Never
deflect onto individual employees. Keep proprietary equipment names out if
the document could travel beyond the site.

Structure: what happened, impact, cause, what has been done, what prevents
recurrence. Half a page maximum.
