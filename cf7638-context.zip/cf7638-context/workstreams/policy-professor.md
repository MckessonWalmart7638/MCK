# Policy Professor: Reference
Updated: 2026-10-06 | Owner: Matt Headland | Site: CF7638 Frederick

This file governs the Policy Professor workstream inside the shared project. Sections 1 through 6 are stable rules. Section 7 is current state. When this file and a chat disagree, this file wins until Matt updates it.

---

## 1. Purpose and reach

The Policy Professor is an animated, painted, single-file HTML companion. Frederick leaders bring him an attendance, conduct, or performance case. He answers from McKesson policy, cites the section, and says when HR/ER must weigh in.

**In scope**
- The tool's policy logic, policy library, intake form, and answer format
- Persona, animation, scenes, music, sound, and voice
- Image-asset prompts and asset processing
- The list of items to confirm with HR/ER

**Out of scope**
- Final employee decisions. The tool is decision support, not an HR determination.
- Drafting DAs. That belongs to the DA workflow (da-notice skill). The Professor can point to it.
- Other facilities work in this project (scorecard, RCA, PM, staffing). Those follow their own rules.

**Audience:** Frederick facilities leaders (supervisors, lead, manager).

**Status:** prototype. Not cleared for live cases until HR/ER confirms the flagged interpretation points.

---

## 2. Source hierarchy

Higher controls lower.

1. **Law, approved protected leave, approved accommodation, and formal HR/ER direction.** The tool never decides these. It routes them.
2. **Corporate policy.** HR-OPS-02, Standards of Workplace Behavior, Anti-Harassment, Substance Abuse, EHS, Confidentiality, Code of Conduct.
3. **Site rules and standards.** Supplemental Work Rules, Frederick Tardiness Agreement, KPI Agreement, Unilabel Verification Policy. These supplement corporate policy and never override it.
4. **Manager tools and notes.** KPI Evidence Checklist, Frederick practice notes, Copilot handoff. Process guidance only, never policy.

Corporate policy is the source of truth. Policy documents Matt uploads are current until he replaces them.

---

## 3. Policy logic rules

**Attendance (HR-OPS-02, effective 05/15/2026)**
- **Points:**
  - tardy (1 minute or more, up to half the shift): 1.00
  - early departure (up to half the shift): 1.00
  - beyond half the shift either way: 2.00
  - No Call / No Show: 4.00
- **Flex PTO:** 1-minute increments for Central Fill. Approved Flex PTO earns no points. Partial coverage earns 1 point (V.B.6).
- **First 89 days:** up to 16 hours of Flex PTO.
- **Consecutive absences:** up to 3 scheduled workdays count as one absence (2 points maximum), then 1 point for each additional day.
- **Corrective action ladder,** counted over a 365-day rolling period:

  | Points | Action |
  |---|---|
  | 2 | Documented Verbal Warning |
  | 4 | Written Warning |
  | 6 | Final Written Warning |
  | 8 | Termination |

  Levels can be skipped when points jump.
- **Two consecutive days with no notification** is a resignation (V.E). Always route to ER.

**Keep the tracks separate**
- Points come only from HR-OPS-02.
- Call-in failures are documented separately as failure to follow policy. They never add points.
- Attendance is never scored as a KPI miss.
- A pattern becomes a performance issue only when its production, overtime, or coverage impact is documented. Isolated issues the employee communicated in advance are excluded.

**KPI**
- A KPI miss requires all of the following:
  - the expectation was communicated beforehand
  - it was within the employee's control
  - objective evidence exists
  - the employee had a chance to explain
  - similarly situated employees are treated the same way
  - the event falls on or after the employee's KPI acknowledgment date
- No acknowledgment date entered means no KPI miss.

**Hard stops: pause and route to HR/ER**
- Any protected circumstance, including protected activity
- Harassment, discrimination, or retaliation
- Substance or impairment
- Safety failures, including lockout/tagout (LOTO)
- Falsification, privacy, or violence
- Termination, 8 points, or the V.E resignation
- A DA that would fall outside the 3-week window

**Interpretation questions:** never resolve these silently. Flag them for HR/ER confirmation.

---

## 4. Product standards

- **One self-contained HTML file** with all assets embedded. No external calls except the Claude API inside Claude.ai.
- **Intake** requires a protected-circumstance answer before any consult runs. The patient-data check stays on.
- **Answers** use fixed sections. Every conclusion cites the document and section. Next steps are tagged Policy, Frederick, Recommendation, or ER.
- **Event type routing.** Each event type sends only the relevant documents to the model. A general question loads all of them.
- **Visual standard.** Painted Northern Renaissance art, animated in Terry Gilliam cut-out style. Museum quality. No cartoon vector scenery.
- **Music.** Medieval and Renaissance character only, using original pieces or public-domain melodies.
- **Exhibit label.** Says who he is and what he does, briefly. Never claims a traditional medium.

---

## 5. Asset conventions

- **Style line:** every image prompt includes the shared style line in full.
- **Background:** isolated pieces go on solid magenta #FF00FF. Never ask for transparency.
- **File names:** numbered and descriptive, for example `01-day.png` or `08-professor.png`.
- **Scene paintings:** the bottom third must be empty, walkable ground.
- **Professor art:** a single full figure, which gets cut into puppet pieces. Never generate separate limbs.
- **Prompt files:** delivered as downloadable .md files.

---

## 6. Never do

- Apply handoff or older policy values over current policy.
- Classify a KPI miss without an acknowledgment date.
- Trace or reuse the contemporary knight reference painting, Monty Python characters, or any other protected artwork.
- Present AI-generated art as a traditional medium.

---

## 7. Current state

| Item | Detail |
|---|---|
| Build | `policy-professor.html`, about 4.6 MB, last output 2026-10-06 |
| Prompt files | `policy-professor-image-prompts.md` (11 assets), `policy-professor-scene-prompts.md` (6 future scenes) |
| Image assets | 01-day, 02-dawn, 03-dusk, 04-night, 05-pear-tree, 06-wisdom-branch, 07-foreground-foliage, 08-professor, 09-heavenly-hand, 10-night-sky, 11-library (.png) |
| Scenes | Garden (4 times of day), Archive, Heavens. The road walk scales him with depth. |
| Sound | 8-track playlist plus a thinking reel, skip button, effects, and optional device voice. All off by default. |

The build workspace resets between sessions, so a rebuild needs the uploads again.

**Policy set (Matt confirmed current, 2026-10-06)**

| Document | Version |
|---|---|
| HR-OPS-02 Nonexempt Attendance | effective 05/15/2026 |
| Standards of Workplace Behavior | October 2013 |
| Anti-Harassment, Non-Discrimination and Non-Retaliation | effective 04/04/2016, last review 05/09/2019 |
| Code of Conduct | not stated |
| Substance Abuse Prevention and Testing | 12/01/2016 |
| EHS Policy | November 2023 |
| Confidentiality Agreement | current version |
| Supplemental Work Rules (Indy Rev 1) | 04/16/2019 body, 04/16/2025 sign-off |
| Frederick Tardiness Agreement | effective 10/05/2026 |
| Hourly Technician KPI Agreement CF7638 | marked proposed revision |
| KPI Evidence and Documentation Checklist CF7638 | not stated |
| Unilabel Label Printer Verification Policy | effective 09/14/2026 |
| PTO Acknowledgment | form only, 01/01/2018 |

**Decisions**

| Date | Decision |
|---|---|
| 2026-10-05 | Use AI-generated painted assets instead of code-drawn art. |
| 2026-10-05 | Corporate policy is the source of truth. The handoff is lowest priority. |
| 2026-10-06 | HR-OPS-02 (05/15/2026) replaces the 2018 and 2023 versions. |
| 2026-10-06 | Exhibit label limited to who he is and what he does. |
| 2026-10-06 | One governing reference file for this workstream (this document). |
