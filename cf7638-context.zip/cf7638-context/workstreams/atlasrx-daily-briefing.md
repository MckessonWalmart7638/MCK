# AtlasRx Daily Briefing: Reference
Updated: 2026-10-06 | Owner: Matt Headland | Site: CF7638 Frederick

This file governs the AtlasRx Daily Briefing workstream (dashboard HTML and the Atlas Daily Brief flow). It wins over chat until Matt updates it.

---

## 1. Purpose and reach

The AtlasRx Daily Operations Briefing is a single HTML dashboard rebuilt by a Power Automate flow. It combines the Nightly Recap, shift reports, inbox, calendar, and the AtlasRx Action Register into a production tracker and a categorized operations queue, over an animated central fill floor background.

**In scope**
- Dashboard HTML: production tracker, operations queue, header metrics, tabs
- Animated background canvas scene
- The Atlas Daily Brief flow: data pulls, digest build, AI prompt hookup, HTML compose, file write
- How Nightly Recap fields map into the tracker

**Out of scope**
- AtlasRx portal platform work (Community Board, Technical Academy, App Library, EARB hosting decision)
- Policy Professor (governed by `PolicyProfessor_Reference.md`)
- Monthly scorecard, RCA writeups, PM reporting, staffing analysis. Those follow their own rules.
- The AI Builder prompt text itself. It lives in Dataverse and is not in any source file here.

**Audience:** Matt Headland.

**Status:** in use, run manually.

---

## 2. Sources of truth

**Production tracker**, in this order:
1. Raw Nightly Recap email body, read verbatim from the `nightlyRecapRaw` slot.
2. PROD section of the AI briefing output. Fallback only, used when the slot is empty.

**Nightly Recap email**
- Subject format: `[EXTERNAL] Nightly Recap MM/DD/YYYY`. The date in the subject is the production date.
- Sent by Walmart. The sender address varies by night: `smart12.s07638.us@wal-mart.com` on 10/04/2026 and `m0l0ji7.s07638.us@wal-mart.com` on 10/05/2026.
- Field labels, exact: WM Week, Date, Total Stores Serviced, Scripts Received, Scripts Filled, Scripts Packed, Total Scripts in System, Orders Received, Orders Filled, Orders Packed, Total Orders in System, Average Scripts/Order, Future RXs Released, Futures Waiting, Host Cancellations, Site Cancellations, Production Start, Production End, Submitted on, Equipment Ticket Today?, Operations Notes, Production Notes, Submission Status.

**Queue content:** AI Builder `Run a prompt` output, split into sections.

**Action history:** AtlasRx Action Register, a SharePoint list.
- Site: `https://mckessoncorp-my.sharepoint.com/personal/matthew_headland_mckesson_com`
- List id: `7b17a24c-aea1-4174-a793-c804d900f135`
- Filter: `Completed eq 0`

**Visual reference for the background:** the six CF7638 floor photos.

| File | Subject |
|---|---|
| `Image__72_.jpg` | Imaging stations |
| `Image__71_.jpg` | Cap elevator |
| `Image__73_.jpg` | Overhead line view |
| `Image__92_.jpg` | Puck with vial |
| `Image__91_.jpg` | Tote |
| `Image__93_.jpg` | Robot canister cell |

---

## 3. Workstream rules

**Flow data windows**

| Step | Rule |
|---|---|
| Get Recent Inbox Emails | Inbox, newest 50, read or unread |
| Get Shift Reports | Inbox, read or unread, search "report", newest 25. Senders: Bradley.McCusker, Tony.Pareene, Ky-Juan.Lewis, Asafo.Acheampong, Mason.Warner (@McKesson.com) |
| Filter Shift Reports 24h | Keep only reports with receivedDateTime within 24 hours of run time |
| Get Nightly Recaps | Inbox, read or unread, search "nightly recap", newest 1 |
| Get Upcoming Meetings | Calendar view from start of the current UTC day through 3 days out |
| Get AtlasRx Action Register | Items where Completed eq 0 |

**AI output parsing**
- Sections are split on `|||`. Items within a section are split on `~~`.
- A leading bullet is stripped from each item.
- These items are dropped as empty: "None", "None outstanding", "None reported", and anything starting "None assigned".
- The template maps split index 0 to 8 in this order: comp, equip, prod, staff, actions, wait, quality, meetings, fyi.
- Any section with no output renders as `• MISSING DATA`.

**Action Register write-back**
- Each item in section index 4 that does not match an existing open Register title creates a new item.
- Matching ignores case, bullets, and `**`.
- New items get: Status Open, Owner Matthew Headland, Source Daily Briefing, FirstSeen and LastUpdated set to today's date in ET.

**Production tracker**
- A field is filled only from a single clean figure. Values carrying shift breakdowns, qualifiers, or sentences show N/A.
- Fill / Received % = Scripts Filled / Scripts Received x 100, shown to 1 decimal. Above 100%, the outer overflow ring shows the excess.
- Production Date comes from the recap Date field and is shown as MM/DD/YYYY.
- Production Window is shown as `MM/DD HH:MM to MM/DD HH:MM`, built from Production Start and Production End.
- Recap Submitted is converted from UTC to the viewer's local time.
- Equipment Ticket accepts Yes or No only.
- Production Notes show with the trailing "Submission Status" text removed. The block stays hidden when no notes are present.
- Production data is never a queue line item. PROD is not in the queue or the tabs.

**Queue**
- Category order: comp, equip, actions, wait, quality, staff, meetings, fyi.
- A checkbox appears on every comp, actions, and wait item.
- Equip and quality items get a checkbox only when they contain action wording, such as follow up, required, repair, escalate, or pending.

---

## 4. Product or deliverable standards

**Deliverable**
- One self-contained HTML file: `AtlasRx-Daily-Briefing.html`.
- The flow writes it to OneDrive at `/AtlasRx/AtlasRx-Daily-Briefing.html` through `Update file`, overwriting the same file each run.

**Page layout, top to bottom**
- Header with the Generated timestamp in ET.
- Metrics bar.
- Tabs: ALL, COMP, EQUIP, STAFF, ACTION, WAIT, QE, MTG, FYI.
- Previous Day Production panel.
- Daily Operations Queue.

**Production panel**
- Header row: date.
- Three KPI tiles: Scripts Received, Scripts Filled, Scripts Packed.
- Fill / Received ring.
- Detail row 1: Production Date, WM Week, Stores Serviced, Production Window.
- Detail grid of 12, in this order: Orders Received, Orders Filled, Orders Packed, Avg Scripts / Order, Total Scripts in System, Total Orders in System, Future RXs Released, Futures Waiting, Host Cancellations, Site Cancellations, Equipment Ticket, Recap Submitted.
- Production Notes block.

**Background canvas**
- Equipment modeled only from the Section 2 floor photos:
  - Flex chain puck loops with wheel bends, guide rails, legs, gearmotors, and photo eyes.
  - Imaging stations: guard box, blue vision tunnel, scale HMI, pendant monitor, stack light.
  - Labelers with label roll.
  - Cap elevator with hopper and capping head.
  - Robotic cell: arm, pedestal, curved canister wall, white enclosure, cable ramp.
  - Amber vial feed lines.
  - Roller tote line with numbered blue totes.
  - Yellow crossover stairs, columns with base guards, pallet racking, polished concrete floor.
- Puck makeup: white base, blue 8-finger collar, amber vial, white cap.
- Puck state changes along the loop: empty puck, vial loaded, labeled, filled, capped.
- All items on a lane move at one speed with fixed spacing. Nothing overlaps.
- Totes have a solid blue rim and solid interior. No rollers show through.
- No brand text on equipment. Tote numbers are the only text.
- Animation runs at display refresh rate, pauses when the tab is hidden, and shows a still frame under reduced motion.
- The canvas skips building when the window has no size and builds on the first frame that has one.

---

## 5. Conventions

- **Dashboard versions:** `atlasrx-briefing_NN.html`, incremented each revision.
- **Flow template:** the Compose step holds the current dashboard version with flow expressions in place of data. The standalone copy is `Compose_Dashboard_HTML_template.txt`.
- **Recap slot:** `<script type="text/plain" id="nightlyRecapRaw"></script>`, placed directly above the production panel. The recap body is inserted with `</script` escaped as `<\/script`.
- **Section text:** inserted with `&`, `<`, and `>` HTML-escaped.
- **Flow name:** Atlas Daily Brief.
- **Flow package:** `Atlas_Daily_Brief_flow.zip`, uploaded whole and not unzipped.

---

## 6. Never do

- Paste a rendered briefing into `Compose - Dashboard HTML`. It freezes every run on that day's data.
- Use `item()` outside an Apply to each.
- Fetch the recap or shift reports unread-only.
- Treat the first number in a shift breakdown as the day total.
- Use AI-written production figures, or an assumed WM Week, when the recap is available.
- Show production numbers as queue line items.
- Let movers on a lane run at different speeds.
- Add equipment to the background that is not in the floor photos.

---

## 7. Current state

| Item | Detail |
|---|---|
| Current dashboard | `atlasrx-briefing_23.html` |
| Flow template | `Compose_Dashboard_HTML_template.txt`, which is v23 plus expressions |
| Flow package | `Atlas_Daily_Brief_flow.zip`, flow resource id `659f52e5-9eb2-4923-a578-aff1d5c12c91` |
| Output file | `/AtlasRx/AtlasRx-Daily-Briefing.html` (OneDrive) |
| Trigger | Manual button |
| Line speeds | Pucks and vials 14 in/s, totes 18 in/s |
| Connections | Office 365 Outlook, Dataverse (DailyOperationsAI), OneDrive for Business, SharePoint |

**Decisions**

| Date | Decision |
|---|---|
| MISSING | Background rebuilt as a 3D floor scene modeled from the six CF7638 floor photos (v19) |
| MISSING | Frame cap removed, line speeds raised (v20) |
| MISSING | Tote rim and interior made solid blue (v21) |
| MISSING | Zero-size canvas guard added (v22) |
| 2026-10-06 | Production numbers belong in the header tracker, not the queue |
| 2026-10-06 | Tracker reads the raw Nightly Recap body verbatim. The PROD section is fallback only. |
| 2026-10-06 | Compose step changed from a hardcoded copy of v22 to the v23 template with expressions |
| 2026-10-06 | Trigger stays manual |
| 2026-10-06 | Unread-only removed from all email pulls |
| 2026-10-06 | Shift reports limited to the last 24 hours |
| 2026-10-06 | Flow renamed from "Copy NEW" to Atlas Daily Brief |
| 2026-10-06 | Image plates for background objects paused |
