# Known Issues

Found during the 2026-10-12 export. Source files were copied verbatim and not corrected. Fix in the source file, then remove the entry.

| # | File | Issue |
|---|---|---|
| 1 | `context/roster.md`, Coverage by day, Friday | Lists Jose Combariza. He resigned and is not in the 2nd shift table. Friday is 7 technicians, not 8. |
| 2 | `context/roster.md`, Coverage by day, Sunday | Lists Philemon Tesfai (Mon to Thu per 2nd shift table) and omits Colin Wakeham (Sun to Thu). |
| 3 | `workstreams/atlasrx-daily-briefing.md`, Decisions | Four v19 to v22 decisions have date MISSING. |
| 4 | `context/contacts.md`, Who owns what | Badge deactivation contact (Joseph Grady) flagged in source as not re-verified. |
