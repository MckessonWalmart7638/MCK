# CF7638 Context Repo

Shared memory, instructions, and reference context for Matt Headland's work at McKesson Central Fill CF7638, Frederick MD. Source of truth for loading context into Claude projects (Claude.ai Projects, Claude Code, or any agent that reads repo files).

> **PRIVATE REPO ONLY.** Contains employee names, schedules, an active ER case, internal SharePoint paths, and McKesson business context. Host on McKesson managed GitHub (Enterprise) with restricted access. Never on a personal or public account.

## Layout

```
.
├── CLAUDE.md                     Entry point: load order, precedence, global rules
├── instructions/
│   ├── user-preferences.md       Global preferences (all projects)
│   └── comms-rules.md            Communication and format rules
├── memory/
│   ├── memory-summary.md         Claude.ai project memory export
│   └── restricted/
│       └── er-cases.md           ER/HR case detail. Load only when needed.
├── context/                      Standing site reference (not status)
│   ├── site-operations.md
│   ├── contacts.md
│   ├── equipment.md
│   └── roster.md
├── workstreams/                  Governing reference per workstream
│   ├── atlasrx-daily-briefing.md
│   └── policy-professor.md
├── skills/                       Org plugin skills (da-notice, exec-brief, ops-scorecard, rca-writeup)
├── KNOWN-ISSUES.md               Discrepancies found at export. Fix in source, then delete the entry.
└── CHANGELOG.md
```

## Using it in a project

| Project type | Load |
|---|---|
| Any | `CLAUDE.md`, `instructions/*` |
| General facilities work | + `context/*`, `memory/memory-summary.md` |
| Daily Briefing build | + `workstreams/atlasrx-daily-briefing.md` |
| Policy Professor build | + `workstreams/policy-professor.md` |
| ER/HR casework | + `memory/restricted/er-cases.md`, `skills/da-notice` |
| Exec comms, scorecard, RCA | + matching `skills/` folder |

- **Claude.ai Projects:** upload the files for that project type as project knowledge. Paste `instructions/user-preferences.md` into Settings > Profile if not already there.
- **Claude Code:** clone or add as a git submodule. `CLAUDE.md` at the repo root is read automatically.

## Maintenance

- `context/` and `workstreams/` files are verbatim copies of the Claude.ai project files as of 2026-10-12. Edit here going forward and re-upload.
- Update the `Updated:` line in any workstream file you change, and log it in `CHANGELOG.md`.
- Re-export memory periodically. Memory drifts; context files do not.
- No em dashes in any file.
