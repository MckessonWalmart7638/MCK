# CLAUDE.md

Entry point for any Claude session using this repo.

## Who and what

Matt Headland, Facilities Manager, McKesson Central Fill CF7638, Frederick MD. Customer is Walmart. Full profile in `instructions/user-preferences.md`.

## Precedence

Higher wins.

1. Matt's instruction in the current session
2. `workstreams/*.md` for that workstream (each states it wins over chat until Matt updates it)
3. `instructions/user-preferences.md` and `instructions/comms-rules.md`
4. `context/*.md`
5. `memory/memory-summary.md` (a summary, not a record)

Live systems (Outlook nightly recaps, Cetaris, System Manager, SharePoint, ServiceNow, Workday) beat any figure in this repo. Retrieve, do not estimate.

## Load on demand

- `memory/restricted/er-cases.md` only for ER/HR casework.
- `skills/<name>/SKILL.md` when the task matches that skill's description.

## Hard rules (summary; full text in instructions/)

- No PHI or patient data. Stop and flag if it appears.
- No em dashes.
- No employee names, contact details, schedules, or proprietary equipment names (FlexBed, LVD, ScriptPick, Unilabeler, Sprint, Tompkins, T-Sort) in external or public facing output.
- CMM / RXAS ownership is in flux. Do not state it as settled.
- Unsure about a McKesson fact: say so.
- Missing details from earlier work: ask for the handoff or check history. Do not assume file names, paths, versions, or decisions.
- Brief, direct, bullets and tables. No preamble or wrap up.
- Default deliverable format is PDF unless told otherwise.
