# Site Operations

Standing structure for CF7638 Frederick. Reference material, not status.

## The operation

Customer is Walmart. McKesson provides all maintenance staffing and
equipment support. Roughly 650 stores serviced.

Six day operation, Saturday dark. Sunday is the peak day, routinely 70,000
plus scripts. Friday and Sunday are the historical coverage gap days.

Current production metrics arrive as nightly recap emails in Outlook.
Retrieve them there rather than relying on any figure stored in this file.
The only volume figure kept here is the Sunday peak, which is a durable
planning constraint rather than a statistic.

## Meeting cadence

| Meeting | When | Who |
|---|---|---|
| The War Room | Tuesdays, 3:00 to 3:30 PM | Matt owns it. Brad, Tony, Ky-Juan, Patrick. Internal McKesson leadership alignment. |
| Weekly facility meeting | Mondays, 3:30 PM | Paul Di Scioscia. Customer facing site review. |
| Weekly downtime / OEE call | Thursdays | Downtime trends, fault assignments, open actions, parts usage. |
| Monthly Facilities Call | 4th Wednesday, 6:00 to 7:00 PM | Hosted by Aaron Wolfe. Network wide. |
| Mason's weekly report | Sunday or Monday | Submitted to Aaron Wolfe, Mick Godsey, and Matt. |
| Monthly scorecard | First week of the following month | Sent to both Walmart and McKesson distribution lists. |

## Escalation

Lead Tech, then Supervisor, then Matt, then Controls/Software (RXAS,
Vanessa Rico), then Walmart leadership (Paul Di Scioscia).

Open items tracked as INC tickets in ServiceNow and THD tickets on the
Tompkins side. Documentation lives in CMMS only. No quick fix sheets.

Matt leads RCA for all significant downtime events. Executive summaries go
to Walmart after major events: transparent, factual, solution forward.

Weekly fault assignments: top faulted assets are assigned to named
technicians with follow up dates.

Daily photo eye alignment walk: one technician per shift, logged as an
indirect inspection work order.

## Preventive maintenance

Site wide ownership through Cetaris. Target above 95 percent weekly
completion across all shifts. Compliance reported weekly to Patrick and
Walmart leadership.

PM procedures are being actively consolidated to eliminate redundancy.
PM Audit and Labor Hours are consolidated into a single Power Apps tool
built by Mason and Ky-Juan, backed by Power Automate.

## Parts and critical spares

Critical spares program with established par quantities per machine.
Weekly parts counts submitted mid week by leads and supervisors.

Categories: belts, suction cups, gripper components, tamp pads, agitators,
motors, printer consumables.

Recurring pain point: bin locations are not maintained, which has cost
repair time. Shortages escalate immediately through McKesson procurement.

## AtlasRx and the CFOps Technical Academy

AtlasRx is the parent CFOps portal. It packages all CFOps apps, onboarding,
training and qualification verification, the technical knowledgebase, and
safety compliance.

The CFOps Technical Academy is the training and qualification component
inside AtlasRx. KEA and VTA are earlier working names for the Academy.
Treat all three as the same thing.

Structure:

- **Knowledgebase** - official repository for all approved SOPs and STPs,
  organized by asset. Managers maintain it. Only verified procedures exist
  in the system.
- **Knowledge verification** - every SOP and STP has a quiz, 3 to 10
  questions, 100 percent required to pass, maximum two attempts. Two
  failures lock the technician out and email the supervisor with full
  results and missed questions. Lockout notifications are live.
- **Recertification** - every quiz retaken every 6 months. Expired quizzes
  stop counting toward qualification.
- **Technical Academy Score (TAS)** - passed active quizzes divided by
  total active quizzes, times 100. Primary KPI for technician development.
- **Asset Mastery Score** - qualification percentage by equipment family.
- **Terminology** - Qualified Technician, Certified Technician, SME
  Candidate.

Built with Mason Warner. Feeds from the Master Troubleshooting Guide, which
consolidates SOPs, STPs, RCAs, and institutional knowledge into a machine
organized master guide. Supervisors and leads contribute, Matt reviews and
approves. Goal is self service troubleshooting regardless of experience
level.

## CFOps AI initiatives

Group formed by Matt and Mason Warner to build AI tools that improve
internal and customer outcomes for Central Fill.

**Inspector Gadget** - RCA and troubleshooting agent built by Mason in
Copilot Studio, running on Claude Opus. Grounded exclusively in site SOPs,
STPs, RCAs, build books, and manufacturer documentation. No internet
access, no ungrounded responses, provides source links. Deployed across
Frederick, Orlando, Indianapolis, Spring, and Everett. Featured in the July
2026 MAPS newsletter under the AIM28 initiative. Mason built it, Matt
expanded the vision and scope.

**Shift Report Triage Agent** and **Briefing Agent** - concepts in the
CFOps AI pipeline.

**Daily report digestion dashboard** - personal action planner pulling
shift reports from Brad, Tony, Ky-Juan, and Walmart and McKesson senders
with a live refresh. Mason's Load Audits flow is the intended data pattern.

**OEE rollup** - shelved with a placeholder procedure.

## OEE and OPE analytics

Mason produces a week over week OEE and OPE dashboard covering Frederick,
Indianapolis, and Spring, distributed to site leaders and leadership.

Watch item: target rates on tracked equipment have been set incorrectly by
the dev team more than once, which distorts machine OEE. Always validate
target rates before drawing conclusions.

## Safety

Monthly safety meetings, rotating topic. LOTO compliance is zero tolerance,
OSHA 1910.147 strictly enforced. Master LOTO binder built to the 13 tab
corporate structure, Brad owns construction. Monthly GSS DC Safety
Performance Scorecard review with a hard feedback deadline. All incidents
and near misses documented and reviewed.

## Hiring and supervisor development

Structured interview guides with weighted 1 to 5 scoring across Leadership
and Management, Problem Solving, Operations and Customer Service, Safety
Compliance, and Overall Fit. 25 points total. Panel is typically Tony,
Brad, Ky-Juan, and Matt.

Priorities: accountability, communication, coaching ability, culture
building, decision making maturity. Leadership qualities first, technical
skills second.

Public facing postings use the recruiting style layout with no proprietary
equipment names.

## Leadership reporting

Monthly site scorecard covers scripts received and filled, futures
released, cancellations (host and site), average hourly production, service
level raw and adjusted, and per store averages.

Monthly billing and expense reporting covers labor, supplies, maintenance
and repair, miscellaneous and travel, and support. Concur for card
expenses.

## HR and compliance

- Falsification violations route through Employee Relations in Workday, not
  Manager Self Service.
- DAs must be submitted within 3 weeks of the incident.
- Sequence: submit documentation to HR, await ER approval, deliver to
  employee.
- Exclude sanctioned break times from violation analysis when cross
  referencing labor logs against security footage.
- PTO and LOA handling follows McKesson and MetLife policy. Denied PTO
  followed by an absence is an unexcused occurrence under the nonexempt
  attendance policy, no grace period.
- Badge deactivation for separated employees is coordinated with Walmart
  security. Sheri Hesler maintains the Walmart user ID roster and
  expirations.

## Systems

| System | Use |
|---|---|
| Cetaris CMMS | PM scheduling, work orders, asset tracking, labor logging |
| System Manager | Production reporting, custom queries (Rx by state, hourly projection, FIFO) |
| Power Apps | RCA database, Technical Academy, PM Audit and Labor Hours app, supervisor checklist |
| SharePoint | SOP and STP library, knowledgebase repository, technician records |
| Power Automate | Workflow automation, notifications, data persistence |
| Copilot Studio | Inspector Gadget and related agents |
| Beckhoff / TwinCAT | PLC systems, event and application log extraction |
| Workday | Requisitions, offers, HR actions |
| Concur | Expense reporting |
| ServiceNow | INC tickets, helpdesk, HR support requests |
| Bambu Lab X1 Carbon | Custom parts and tooling |
| Teams / Outlook | Primary communication |

## Where the data lives

M365 is connected. Retrieve from the source rather than assuming or asking
Matt to paste.

| Data | Source |
|---|---|
| Current production metrics, service level, daily volume | Nightly recap emails in Outlook |
| Work order history, PM completion, asset records, labor logging | Cetaris CMMS |
| Production queries: Rx by state, hourly projection, FIFO | System Manager |
| SOPs, STPs, knowledgebase, technician records | SharePoint |
| Downtime and OEE trending | Mason's weekly dashboard, plus the Thursday call |
| Open technical issues | ServiceNow INC tickets, THD tickets on the Tompkins side |
| Requisitions, offers, HR actions | Workday |
| Expenses | Concur |

If a number is needed and it lives in one of these systems, go get it. Do
not estimate from context.

## Recurring workflows

- **Run the downtime report** - Matt uploads the weekly xlsx, output is a
  branded multi page PDF using matplotlib charts and McKesson colors, same
  template every time.
- **Frederick scorecard** - monthly Excel update matching the prior month's
  tab exactly, then the email version to both distribution lists.
- **Daily report pull** - recap of the most recent shift reports from Brad,
  Tony, and Ky-Juan plus Walmart and McKesson senders, with pending
  maintenance actions and key events or risks called out.

## Weekly OEE Report, hard rules

- Use the exact same section order, headings, labels, and formatting every
  time.
- Do not rename, add, or remove sections.
- If data is missing, write "MISSING DATA" in that field.
- Do not change tone or verbosity.
- Output only the final report.
- Follow the uploaded template and example exactly.
