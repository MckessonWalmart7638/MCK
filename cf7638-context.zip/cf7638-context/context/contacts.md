# Contacts and Routing

Who to go to for what. Names and titles are also in the Microsoft 365
directory. What is here instead is relationship, ownership, and routing,
which the directory does not carry.

## Chain

**Patrick Alfonso**, Director of Pharmacy Operations, Central Fill. Matt's
manager on paper and in Workday. Attends the War Room. Receives weekly PM
compliance. Approves site level decisions.

**Mark Edwards**, skip level above Patrick.

**Aaron Wolfe**, Director of Facilities Programs / Facilities Operations,
McKesson PSaS. Peer director with functional authority over facilities
work. Matt answers to him in practice but he is not the Workday reporting
line. Hosts the Monthly Facilities Call. Receives Mason's weekly report.
When facilities standards, network programs, or cross site alignment are in
play, this is the line.

**Alex Hennum**, VP and General Manager, Central Fill. Executive level.

**Mick Godsey**, Senior Manager of Facility Operations. Receives Mason's
weekly report.

## Escalation sequence

Lead Tech, then Supervisor, then Matt, then Controls and Software, then
Walmart leadership.

**Vanessa Rico** is the primary escalation contact for controls and
software. That group operates under several names: RXAS, CoverMyMeds, CMM,
Sanitas, Controls, Software. All the same people.

**Paul Di Scioscia**, General Manager, Health and Wellness, CF7638. The
Walmart site executive and the top of the customer facing escalation path.
Weekly facility meeting on Mondays. Major event summaries go to him.

## Who owns what

| Need | Go to |
|---|---|
| Controls, software, Sanitas, PLC escalation | Vanessa Rico (RXAS / CMM) |
| System Manager reporting, custom report approval, dev escalation | Hommy Lopez |
| Service level definitions, finance and reporting package | Molly Lopez |
| Data analytics | John Fitch, Phil Rivera |
| Engineering and program | Jacqueline Dawson, Brinton Satterfield, Chelsey Traband, Jonathan Kriebel |
| Marketing and internal publication | Michel Le, SCO Marketing and Communications |
| Walmart user IDs, badge expirations, roster verification | Sheri Hesler |
| Badge deactivation for separated employees | Walmart security. Joseph Grady was the Security Manager per an older record. Not re-verified. Confirm before relying on it. |

Molly Lopez owns service level definition consistency across Walmart sites.
Worth involving whenever a service level number is disputed or compared
across sites.

## Walmart operations contacts

| Name | Role |
|---|---|
| Joel Samuel | Operations Manager |
| Jose Sanchez | Operations Manager |
| Binyam Tefera | Operations Manager |
| Aleksander Urban | Production Systems Manager, Pharmacy H&W |
| Shane Martin | PSM, Health and Wellness NSO |
| Tristan Canter | Manager, Patient Safety |
| David Seegolam | Site operations |
| Jaime Ferrer | Site operations |
| Alicia Egyir | Site operations |

## Cross site peers

Use these for benchmarking, shared troubleshooting, and network comparisons.

| Name | Site | Role |
|---|---|---|
| Daniel Holznagel | Orlando | Maintenance Operations Manager |
| Daniel Martes | Orlando | Facility Maintenance Supervisor |
| Nigel Allen | Spring TX | Maintenance Operations Manager |
| Jeff Gilstrap | Indianapolis (Plainfield) | Manager |
| Cole Shaffer | Indianapolis | |
| Manuel Perez | Everett | |

Tony Pareene transferred in from Orlando, which makes that site the most
natural comparison point on process questions.

## Notes

Some Walmart access rosters still list Matt as "Site Manager." Internally
and on all signatures he is Facilities Manager.

Never carry contact details or employee names into external or public
facing output.
