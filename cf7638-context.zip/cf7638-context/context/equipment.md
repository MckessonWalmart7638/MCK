# Equipment

Fully automated central fill pharmacy, CF7638 Frederick MD.

## Ownership split

CMM (RXAS, CoverMyMeds, Sanitas, Controls, Software, all the same group)
provides and manages the primary operations software, Sanitas, designs the
dispensing solutions, and sources third party assets with or without
modification. Matt's team owns mechanical and hardware support and
maintenance. Walmart is the customer served in daily operations.

CMM is currently being absorbed into Central Fill Ops. Ownership lines are
in flux. Do not state them as settled.

## Dispensing

- **FlexBed** - dispensing solution designed by CMM.
- **LVD** - Low Volume Dispenser. Separate asset from FlexBed. Primary
  source of dispensing exceptions.
- **ScriptPick** - automated pill pick.
- **Parata** - cell based dispensing. Third party, sourced through CMM.
- **Kalish** - canister based dispensing.

## Labeling and imaging

- **Unilabelers** - vial labeling stations. Original install plus a 2024
  addition.
- **Puck and Laden Scales** - Ishida imaging scales. Calibration and
  exception events.
- **Printers** - Zebra (GK420D, ZD421, ZT411), Intermec, Honeywell,
  DataMax.

## Sortation and conveyance

- **Tompkins t-Sort / Flex Sorter** - grid based robotic sorting, upper and
  lower platforms, command center PCs. Open items tracked as THD tickets on
  the Tompkins side.
- **Conveyors** - Nedco, Hytrol, Flex Link, Dorner.
- **Euro Sort**.

## Bagging and packaging

- **Sprint Baggers / Autobagger 550** - bagging automation.
- **Semi-auto baggers and induction stations** - inductions 1 through 19
  plus. Double feed and no read issues are recurring.
- **Sealed Air autobaggers** - third party, sourced through CMM.
- **Sharp autobaggers** - third party, sourced through CMM.
- **Capper (SureKap)** - cap seating and jams.
- **Strapper**, **Lantech box maker**, **OR stations**.

## Handling and support equipment

- **Bottle Orienter / Depucker**.
- **Hopper Cleaning Station** - S3 and S4.

## Controls and vision

- **Beckhoff PLC and TwinCAT** - Structured Text. Event and application log
  extraction.
- **SICK scanners and cameras**.

## Fabrication

- **Bambu Lab X1 Carbon** - custom parts, tooling, and fixtures for the
  facility. Standing capability, not a side project.

## Fault routing

Mechanical, hardware, wear parts, alignment, and physical jams are Matt's
team. Software behavior, Sanitas, PLC logic, recipe and parameter changes,
and vision configuration route to Controls and Software (Vanessa Rico).

The line blurs most often on scanner no reads and photo eye faults, which
present as software but usually resolve as alignment or contamination.
Check the mechanical cause before escalating.

Known recurring failure points, useful for triage:

- LVDs are the primary source of dispensing exceptions.
- Induction stations 1 through 19 plus: double feed and no read.
- SureKap capper: cap seating and jams.
- Puck and Laden scales: calibration drift and exception events.

## Public facing restriction

Never use proprietary equipment names in public facing documents such as
job postings or external communications. This covers FlexBed, LVD,
ScriptPick, Unilabeler, Sprint, Tompkins, and t-Sort. Substitute generic
descriptions such as "automated dispensing, labeling, and robotics
equipment."
