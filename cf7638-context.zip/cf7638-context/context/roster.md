# Roster

Facilities organization, McKesson Central Fill CF7638, Frederick MD.

21 positions: 14 Maintenance Technicians, 1 Lead Technician, 3 Supervisors,
1 System Administrator, 1 Enabler, 1 Manager. Three shifts, six day
operation. Saturday is dark for the entire site.

Current vacancies: 1 Maintenance Technician, 3rd shift.

## Leadership

| Name | Role | Shift | Days |
|---|---|---|---|
| Matt Headland | Facilities Manager | Days | Mon to Fri |
| Bradley McCusker | Supervisor | 1st | Sun to Thu |
| Tony Pareene | Supervisor | 2nd | Mon to Fri |
| Ky-Juan Lewis | Supervisor | 3rd | Sun to Thu |

Ky-Juan is a supervisor, not a lead technician. He is the most trusted
escalation point on nights. Tony transferred in from Orlando and started
full time June 1, 2026.

## Support

| Name | Role | Hours | Days |
|---|---|---|---|
| Mason Warner | System Administrator | 12:00 PM to 8:00 PM | Sun to Thu |
| Samual Kidane | Enabler | 9:00 AM to 5:00 PM | Sun to Thu |

Mason is not a technician. He runs data, systems, live production tests,
and the AI tooling. He co-leads the CFOps AI effort with Matt Headland.

## Lead Technician

| Name | Role | Hours | On | Off |
|---|---|---|---|---|
| Asafo Acheampong (AJ) | Lead Maintenance Technician | 8:00 AM to 6:30 PM | Sun, Mon, Thu, Fri | Tue, Wed, Sat |

Refer to Asafo Acheampong as AJ. Selected from the existing technician
roster. Thursday is retained on this pattern so the Lead covers the weekly
downtime and OEE call.

## Maintenance Technicians

**1st shift**

| Name | Days |
|---|---|
| Ryan Spence | Sun to Thu |
| Chauncey Spencer | Mon to Fri |
| Carl Jackman | Mon to Fri |
| Casey O'Sullivan | Sun to Thu |
| Kelly Nielsen | Sun to Thu |

**2nd shift**

| Name | Days |
|---|---|
| Jeremy Johnson | Mon to Fri |
| Bryce Hornberger | Sun to Thu |
| Philemon Tesfai | Mon to Thu |
| Colin Wakeham | Sun to Thu |

**3rd shift**

| Name | Days |
|---|---|
| Leighton Heath | Mon to Fri |
| Denzel Varner | Sun to Thu |
| Brandon Wilt | Mon to Fri |
| VACANT | Sun to Thu |

**4D**

| Name | Hours | On | Off |
|---|---|---|---|
| Matt Ryan | 10:00 AM to 8:30 PM | Sun, Mon, Tue, Fri | Wed, Thu, Sat |

Note: the roster contains both Matt Headland (Facilities Manager) and Matt
Ryan (Maintenance Technician). Use full names in any output where the
distinction matters.

Steven Horman and Isaiah Capers appear in older records and are not active
employees. Do not reference them as current staff.

## The 4D schedule

Two positions built on a 4x10 pattern, internally called 4D Tech. Created
to close Friday and Sunday coverage gaps without changing any existing
technician's schedule.

- **Lead Maintenance Technician** (Req JR0150332): AJ, Sun/Mon/Thu/Fri.
- **4D Maintenance Technician**: Matt Ryan, Sun/Mon/Tue/Fri. Moved from
  2nd shift into this seat.

## Coverage by day

Derived from the schedule above. Use this to answer staffing and coverage
questions directly.

| Day | Technicians on | Supervisor | Notes |
|---|---|---|---|
| Sunday | Ryan Spence, Casey O'Sullivan, Kelly Nielsen, Bryce Hornberger, Philemon Tesfai, Denzel Varner, AJ, Matt Ryan | Brad (1st), Ky-Juan (3rd) | Peak day. Tony off, Matt Headland off. Thinnest leadership coverage against the highest volume. |
| Monday | All | All three | Fullest day. |
| Tuesday | All except AJ | All three | |
| Wednesday | All except AJ and Matt Ryan | All three | |
| Thursday | All except Matt Ryan | All three | Downtime and OEE call. AJ on by design. |
| Friday | Chauncey Spencer, Carl Jackman, Jeremy Johnson, Jose Combariza, Leighton Heath, Brandon Wilt, AJ, Matt Ryan | Tony (2nd) only | Historical gap day. Brad and Ky-Juan off. |
| Saturday | None | None | Site dark. |

The vacant 3rd shift seat is a Sun to Thu pattern, so filling it adds
coverage to Sunday, the peak day, and nothing to Friday.

## Coverage notes

Sunday is the peak production day, routinely 70,000 plus scripts. Friday
and Sunday are the historical coverage gap days and the reason the 4D
pattern exists.

On call rotation, effective June 1, 2026: mandatory weekly rotation,
roughly one week in twelve per technician. Friday holds 2 technicians,
Sunday minimum is 4. Response expectation is 30 minutes to contact and
2 hours to site if activated. Supervisors post the schedule weekly and
log every activation attempt.

## Handling

Employee names, schedules, and performance context are working data for
internal use. Never carry employee names, contact details, or schedules
into external or public facing output.
