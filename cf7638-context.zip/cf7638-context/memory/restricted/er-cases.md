# ER Cases (Restricted)

Exported 2026-10-12 from Claude.ai project memory. Confidential employee relations material. Internal use only. Do not load into any project that does not need it.

## HRC0739264 (Matthew Ryan)

- Status: active, under review.
- Built: evidence packet, timeline analysis, 60 day Performance Improvement Plan, conditional ER email (cc Patrick Alfonso, Tony Pareene).
- Two attendance incidents held for ER's leave review determination rather than cited as misconduct, given reported family/emergency circumstances.
- The Hourly Technician KPI Agreement (split into employee facing and manager only evidence documents) is NOT used for this case. Its effective date clause excludes prior events.
- Matthew Ryan is the roster's "Matt Ryan" (4D Maintenance Technician). Not Matt Headland.
