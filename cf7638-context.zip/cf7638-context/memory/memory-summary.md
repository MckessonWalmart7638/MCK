# Memory Summary

Exported 2026-10-12 from Claude.ai project memory (CF7638 project scope).

Memory is a generated summary of past chats, not a record. Where this file and a `context/` or `workstreams/` file disagree, the context or workstream file wins. ER/HR case detail lives in `memory/restricted/`.

## Purpose and context

- Matt Headland, Facilities Manager, McKesson Central Fill, site CF7638, Frederick MD. Central fill pharmacy fulfilling prescriptions for Walmart.
- Reporting line: Patrick Alfonso (Director, Pharmacy Operations). Skip level: Mark Edwards. Aaron Wolfe (Director, Facilities Programs) holds functional authority over facilities work.
- Concurrent initiatives: technician staffing and scheduling, ER/HR case documentation, AtlasRx platform, MAPS RCA/CAPA governance framework, recurring QBR and leadership reporting.

**Key colleagues**

| Name | Role / relevance |
|---|---|
| Mason Warner | System Administrator. Primary technical build partner: AtlasRx tools, Inspector Gadget, OEE dashboards, PM Audit tool |
| Tony Pareene | Maintenance Supervisor |
| AJ Acheampong | Lead Technician |
| Paul Di Scioscia | Customer facing facilities contact (Walmart) |
| Jackie Dawson | RCA/CAPA charter owner |
| Dan Holznagel, Chelsey Traband | MAPS RCA/CAPA document co-owners |
| Jasmin Ball | Walmart Quality and Patient Safety |
| Also active | Brad, Ky-Juan Lewis, Patrick Alfonso, Vanessa Rico, Brinton Satterfield |
| Jose Combariza | Former 2nd shift Maintenance Technician (Mon to Fri). Resigned. Not active staff. |

**Working style**
- Direct, correction driven, detail oriented. Terse factual corrections.
- Strict source grounding. No fabricated figures, no assumptions.
- Minimal, uncluttered document design.
- Separates centrally owned content (not his to edit) from his own accountability areas.
- Compressed, bulleted, structured chat output. Prose only for genuine reasoning, 3 to 4 sentences max. Does not apply to formal deliverables with a required structure.

## Current state (as of 2026-10-12)

**Policy Professor.** Governed by `workstreams/policy-professor.md`. Policy set listed there is current until Matt says otherwise. Corporate policy beats local handoff or summary docs. Six interpretation points still flagged for HR/ER confirmation before live use.

**ER case HRC0739264.** Active. See `memory/restricted/er-cases.md`.

**AtlasRx platform**
- Proposed authenticated single front door for Central Fill Operations.
- Three layers: Community Board, CFOps Technical Academy, App Library.
- Hosts existing tools: PM Audit Tool, Labor Hour Efficiency Tool, Inspector Gadget, RCA App, Technical Academy.
- In Enterprise Architecture Review Board (EARB) review for architecture, hosting, and authentication. This is the primary blocker.
- Built: tracker spreadsheet, executive briefing materials (deck, meeting PDF, concept brief).

**AtlasRx Daily Operations Briefing.** Governed by `workstreams/atlasrx-daily-briefing.md`.
- Recent fixes: hardcoded static data in a Compose step, unread-only email filters, empty AI Builder context field causing blank output.
- Queue UI cut from 7 columns to 4 (Item / Owner / Due / Clear) per "less is more."

**MAPS RCA/CAPA Interim Operating Model**
- Through Rev 004. Eight sections plus document control block.
- Owners: Matt Headland, Dan Holznagel, Chelsey Traband.
- Mandatory RCA triggers: SEV1 only, or customer requested.
- Consolidated Event Owner accountability. Nine stage lifecycle.
- Open: six enterprise QMS document citations need verification. Timing standard values pending working group alignment.

## On the horizon

- Policy Professor: six interpretation points need HR/ER sign off before live deployment.
- AtlasRx: EARB decision on architecture, hosting, authentication is the critical path.
- Staffing: hard floor of about 21 countable technicians to protect consecutive days off for all existing staff under Saturday dark scheduling (or +5 new hires if one new seat absorbs a midweek day). Two incoming technicians confirmed for October/November starts.
- RCA/CAPA: open leadership question on whether SEV1 only is too narrow versus the enterprise standard. Repeat SEV2 failures across sites currently have no mandatory trigger.
- Daily Briefing known gaps: chart history needs a wider email filter; staffing headcount likely needs a SharePoint roster source; action checkbox state does not persist across reloads.

## Key learnings and principles

- Corporate or enterprise policy and centrally owned documents (for example, corporate built QBR decks) are never Matt's to edit or debate. His accountability is his site's data and being ready to answer as SME.
- Protecting consecutive days off for existing technicians is a binding constraint, not a preference. It reshapes staffing math under constrained operating day patterns.
- ER/HR documentation gets multiple self audit passes before finalizing. This reliably catches factual errors, selective quoting, and individualized expectations not grounded in policy. Treat as mandatory.
- Attendance point disputes are conceded in the employee's favor when policy supports it, even while separate conduct concerns are pursued. Distinct tracks.
- Version control: when a policy document updates, refresh every dependent tool and figure.
- Technical builds: preserve exact file structure (XML level edits, no full library resaves) when the deliverable must stay byte identical except for targeted values.

## Approach and patterns

- Single self-contained HTML files. No build steps, no external dependencies, no npm/CDN. Managed device constraint.
- Iterative, correction heavy. Mid build scope redirects are normal ("just edit values, no formatting changes," "remove hedging language," "less is more"). Interpret precisely without long back and forth.
- Major workstreams get a governing reference doc: Purpose, Sources of Truth, Workstream Rules, Product Standards, Conventions, Never Do, Current State. No open items or next steps sections in these templates (standing instruction).
- Formal citations require verified attribution (sender, title, date) via email search before citing.
- Split employee facing documents from manager only evidence and tooling.
- Visual references (photos, JSX mockups, brand guidelines) are strict build references. Expect pushback when output drifts.
- Validates technical output by rendering to PDF, page by page visual review, and regression testing.

## Tools and resources

- Microsoft 365 (Outlook, Calendar, Teams, SharePoint): sourcing threads, verifying attribution, pulling operational data. Needs per session reconnection. About 200,000 character attachment read cap; larger files need direct upload.
- Python document manipulation: XML level docx/xlsx edits, openpyxl with care for style and label preservation, ReportLab for PDF.
- McKesson colors: Navy #003C71, Orange #E87722.
- Power Automate with AI Builder (Atlas Daily Brief flow).
- GPT Astra for photorealistic equipment imagery on magenta key backgrounds for compositing.
